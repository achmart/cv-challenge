% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 3027.961896149918175 ; 3027.676582611122740 ];

%-- Principal point:
cc = [ 1546.421897002480364 ; 1000.678771735502323 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.062765158376628 ; 0.063869377788303 ; -0.000456628021983 ; 0.002669389654696 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 100.039838830820116 ; 97.225320270030693 ];

%-- Principal point uncertainty:
cc_error = [ 44.655075647384415 ; 31.347273202997542 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.029032846604302 ; 0.071050238994308 ; 0.002740474655801 ; 0.004189052235115 ; 0.000000000000000 ];

%-- Image size:
nx = 3000;
ny = 2000;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 3;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 1.832120e+00 ; 2.520544e+00 ; -8.495801e-02 ];
Tc_1  = [ -7.839022e+01 ; -3.322049e+02 ; 1.410892e+03 ];
omc_error_1 = [ 8.369436e-03 ; 1.480583e-02 ; 2.363849e-02 ];
Tc_error_1  = [ 2.096399e+01 ; 1.478650e+01 ; 4.775368e+01 ];

%-- Image #2:
omc_2 = [ -2.142193e+00 ; -2.168079e+00 ; 3.233400e-02 ];
Tc_2  = [ -5.288886e+01 ; -6.204247e+01 ; 9.052096e+02 ];
omc_error_2 = [ 7.649376e-03 ; 8.154647e-03 ; 1.822381e-02 ];
Tc_error_2  = [ 1.332926e+01 ; 9.378923e+00 ; 2.921172e+01 ];

%-- Image #3:
omc_3 = [ 1.919428e+00 ; 1.911592e+00 ; 6.853337e-01 ];
Tc_3  = [ -3.712686e+02 ; -6.378297e+01 ; 8.795489e+02 ];
omc_error_3 = [ 1.063245e-02 ; 9.132868e-03 ; 1.794650e-02 ];
Tc_error_3  = [ 1.309939e+01 ; 9.564549e+00 ; 3.156608e+01 ];

